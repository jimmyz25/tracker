CREATE TRIGGER Row_Security_Trigger_DELETE_RELLOG
                BEFORE DELETE ON RelLog_T
                FOR EACH ROW
                WHEN old.Station <> "RelStation#1"
                BEGIN
                    SELECT
                        CASE
                            WHEN TRUE THEN
                                RAISE (ABORT,'Not Your Data, Read Only')
                        END;
                END;

