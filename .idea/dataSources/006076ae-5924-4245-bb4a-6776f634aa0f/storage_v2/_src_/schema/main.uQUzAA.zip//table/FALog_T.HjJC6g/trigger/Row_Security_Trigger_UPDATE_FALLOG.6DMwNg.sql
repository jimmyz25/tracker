CREATE TRIGGER Row_Security_Trigger_UPDATE_FALLOG
                BEFORE UPDATE ON FALog_T
                FOR EACH ROW
                WHEN old.Station <> "RelStation#1"
                BEGIN
                    SELECT
                        CASE
                            WHEN TRUE THEN
                                RAISE (ABORT,'Not Your Data, Read Only')
                        END;
                END;

